function gizleGoster(ID) {
    var secilenID = document.getElementById(ID);
    if (secilenID.style.display == "none") {
      secilenID.style.display = "";
    } else {
      secilenID.style.display = "none";
    }
  }